class PermissionError(Exception):
    """Exceção lançada quando uma permissão é requerida mas o usuário não a possui."""
    pass
